# Forge for iPhone

This Xcode project builds an iPhone app for your existing tracker at https://jacked.floot.app. It uses the current published routine and your account's saved workouts. Sign in once inside the app; its login is separate from Safari's. Internet is required. Wait for “All changes saved” before leaving the tracker.

## Build in the cloud (no Xcode installation)

1. Sign in to GitHub and create an empty repository, for example `forge-iphone`.
2. Upload the contents of this folder to the repository's root. `Forge.xcodeproj`, `Forge`, and `Build IPA.command` must be at the root, not inside another folder.
3. Include the hidden `.github/workflows/build-ipa.yml` file. On a Mac, press Command–Shift–Period in Finder to show hidden files. If GitHub's upload does not include this folder, use **Add file → Create new file**, enter `.github/workflows/build-ipa.yml` as its name, and paste the supplied workflow into it.
4. Open **Actions → Build iPhone IPA → Run workflow**.
5. Once the run succeeds, open it and download **Forge-iPhone-IPA** under **Artifacts**. Unzip the download to get **Forge-unsigned.ipa** and give that file to your installer.

No Apple credentials or signing certificates are needed for the unsigned build. It does not contain your workout data or account password; you sign in to the tracker after installation.

[Standard GitHub cloud builds are free for public repositories](https://docs.github.com/en/actions/reference/runners/github-hosted-runners). Private repositories use your account's included build minutes and storage; additional usage depends on your billing settings. The workflow runs only when you press **Run workflow**.

**Current status:** source project and cloud workflow prepared and statically checked. The iPhone code has not been compiled or tested on a device. A successful cloud run is required before an IPA exists. This source ZIP is not an IPA.

## Optional local build

Install [Xcode from the Mac App Store](https://apps.apple.com/app/xcode/id497799835). Open Xcode once, accept its setup prompts, and install iOS platform support if prompted. Simulator downloads are optional for building the IPA.

Once Xcode is ready, tell Codex “Xcode is ready” to finish the build here. Alternatively, double-click **Build IPA.command** in this folder. The resulting file will be **dist/Forge-unsigned.ipa**. It contains a compiled iPhone app; your installation tool must sign it. No Apple developer account is required for this unsigned build.

## Use it

Choose the date, enter each set's weight and reps, then check that set when done. Add notes and finish the workout. History shows saved sessions; Progress shows lifts and personal bests. The lb/kg switch converts displayed weights.

## Open or edit the project

Open **Forge.xcodeproj** in Xcode. The app supports iPhone on iOS 16 or later. It has no third-party dependencies. The target uses automatic signing for Xcode's Run workflow; choose your own team if running directly on a device. The IPA helper explicitly disables signing for the build handled by your own installer.

`Forge/TrackerView.swift` holds the tracker URL. The bundle identifier is `app.forge.jacked.training`, and the home-screen name is Forge. This is an independent local wrapper; it does not use or export Floot's native build project.

Reference: [Apple's WKWebView documentation](https://developer.apple.com/documentation/webkit/wkwebview).
