#!/bin/bash
set -euo pipefail

forge_root="$(cd "$(dirname "$0")" && pwd)"
cd "$forge_root"

forge_finish() {
    if [ -t 0 ]; then
        printf '\nPress Return to close this window.\n'
        read -r _ || true
    fi
}
trap forge_finish EXIT

if [ -d /Applications/Xcode.app/Contents/Developer ]; then
    export DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer
fi
if ! /usr/bin/xcrun --find xcodebuild >/dev/null 2>&1; then
    printf 'Install Xcode from the Mac App Store and open it once to finish setup.\n'
    exit 1
fi
if ! /usr/bin/xcrun --sdk iphoneos --show-sdk-path >/dev/null 2>&1; then
    printf 'Open Xcode and install its iOS platform support, then try again.\n'
    exit 1
fi

printf 'Building the iPhone app. This can take a few minutes…\n'
/usr/bin/xcrun xcodebuild \
    -project Forge.xcodeproj \
    -scheme Forge \
    -configuration Release \
    -sdk iphoneos \
    -destination 'generic/platform=iOS' \
    -derivedDataPath "$forge_root/build/DerivedData" \
    CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO \
    build

forge_app="$forge_root/build/DerivedData/Build/Products/Release-iphoneos/Forge.app"
forge_executable="$(/usr/libexec/PlistBuddy -c 'Print CFBundleExecutable' "$forge_app/Info.plist")"
if ! /usr/bin/file "$forge_app/$forge_executable" | /usr/bin/grep -q 'Mach-O.*arm64'; then
    printf 'The expected iPhone executable was not built. No IPA created.\n'
    exit 1
fi
forge_platform="$(/usr/libexec/PlistBuddy -c 'Print CFBundleSupportedPlatforms:0' "$forge_app/Info.plist")"
if [ "$forge_platform" != iPhoneOS ]; then
    printf 'This is not an iPhone device build. No IPA created.\n'
    exit 1
fi

forge_package="$(/usr/bin/mktemp -d "$forge_root/build/package.XXXXXX")"
/bin/mkdir "$forge_package/Payload"
/usr/bin/ditto "$forge_app" "$forge_package/Payload/Forge.app"
/bin/mkdir -p "$forge_root/dist"
/bin/rm -f "$forge_root/dist/Forge-unsigned.ipa"
/usr/bin/ditto -c -k --keepParent "$forge_package/Payload" "$forge_root/dist/Forge-unsigned.ipa"
/bin/rm -rf "$forge_package"
printf '\nCreated: %s/dist/Forge-unsigned.ipa\nUse your installer to sign and install this IPA.\n' "$forge_root"
if [ "${CI:-}" != true ]; then
    /usr/bin/open "$forge_root/dist"
fi
