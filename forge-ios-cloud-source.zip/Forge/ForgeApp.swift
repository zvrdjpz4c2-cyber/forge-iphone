import SwiftUI

@main
struct ForgeApp: App {
    var body: some Scene {
        WindowGroup {
            TrackerView()
                .preferredColorScheme(.dark)
        }
    }
}
