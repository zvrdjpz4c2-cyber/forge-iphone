import SwiftUI
import WebKit

private let trackerURL = URL(string: "https://jacked.floot.app")!
private let forest = Color(red: 21 / 255, green: 33 / 255, blue: 23 / 255)
private let lime = Color(red: 198 / 255, green: 243 / 255, blue: 107 / 255)

final class BrowserState: ObservableObject {
    @Published var loading = true
    @Published var failed = false
    @Published var retry = 0
}

struct TrackerView: View {
    @StateObject private var browser = BrowserState()

    var body: some View {
        ZStack {
            forest.ignoresSafeArea()
            TrackerBrowser(state: browser)
                .opacity(browser.failed ? 0 : 1)

            if browser.failed {
                VStack(spacing: 18) {
                    Image(systemName: "wifi.exclamationmark")
                        .font(.system(size: 36))
                        .foregroundStyle(lime)
                    Text("Couldn't open your tracker")
                        .font(.title2.bold())
                    Text("Check your internet connection, then try again.")
                        .multilineTextAlignment(.center)
                        .foregroundStyle(.secondary)
                    Button("Try again") {
                        browser.failed = false
                        browser.loading = true
                        browser.retry += 1
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(lime)
                    .foregroundStyle(forest)
                }
                .padding(32)
            } else if browser.loading {
                VStack {
                    HStack(spacing: 10) {
                        ProgressView().tint(lime)
                        Text("Opening Forge…").font(.subheadline)
                    }
                    .padding(14)
                    .background(forest.opacity(0.95), in: Capsule())
                    .accessibilityElement(children: .combine)
                    Spacer()
                }
                .padding(.top, 12)
                .allowsHitTesting(false)
            }
        }
    }
}

struct TrackerBrowser: UIViewRepresentable {
    @ObservedObject var state: BrowserState

    func makeCoordinator() -> Coordinator {
        Coordinator(state: state)
    }

    func makeUIView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        // Keep the user's login between launches, inside this app's own storage.
        configuration.websiteDataStore = .default()
        let view = WKWebView(frame: .zero, configuration: configuration)
        view.navigationDelegate = context.coordinator
        view.isOpaque = false
        view.backgroundColor = UIColor(red: 21 / 255, green: 33 / 255, blue: 23 / 255, alpha: 1)
        view.scrollView.backgroundColor = view.backgroundColor
        view.allowsBackForwardNavigationGestures = true
        context.coordinator.retry = state.retry
        view.load(URLRequest(url: trackerURL))
        return view
    }

    func updateUIView(_ view: WKWebView, context: Context) {
        guard context.coordinator.retry != state.retry else { return }
        context.coordinator.retry = state.retry
        if view.url?.host == trackerURL.host {
            view.reload()
        } else {
            view.load(URLRequest(url: trackerURL))
        }
    }

    final class Coordinator: NSObject, WKNavigationDelegate {
        let state: BrowserState
        var retry = 0

        init(state: BrowserState) {
            self.state = state
        }

        func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
            state.failed = false
            state.loading = true
        }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            state.loading = false
        }

        func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
            showFailure(error)
        }

        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
            showFailure(error)
        }

        private func showFailure(_ error: Error) {
            let failure = error as NSError
            guard !(failure.domain == NSURLErrorDomain && failure.code == NSURLErrorCancelled) else { return }
            state.loading = false
            state.failed = true
        }

        func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
            state.loading = false
            state.failed = true
        }

        func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                     decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            guard let url = navigationAction.request.url else {
                decisionHandler(.cancel)
                return
            }
            // Keep the tracker and sign-in in the app; open outside links normally.
            if url.scheme == "https", url.host == trackerURL.host {
                if navigationAction.targetFrame == nil {
                    decisionHandler(.cancel)
                    webView.load(navigationAction.request)
                } else {
                    decisionHandler(.allow)
                }
            } else if ["https", "http", "mailto", "tel"].contains(url.scheme ?? "") {
                decisionHandler(.cancel)
                UIApplication.shared.open(url)
            } else {
                decisionHandler(.cancel)
            }
        }
    }
}
